def send_whatsapp(message):
    print(f"Sending WhatsApp alert: {message} (simulated)")