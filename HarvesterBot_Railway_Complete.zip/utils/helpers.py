def get_current_time():
    from datetime import datetime
    return datetime.now().isoformat()