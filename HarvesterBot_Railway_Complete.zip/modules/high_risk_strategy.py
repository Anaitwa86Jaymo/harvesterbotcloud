def run_strategy():
    print("[HIGH-RISK] Running high volatility strategy... (Simulated)")