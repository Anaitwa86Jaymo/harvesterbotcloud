def run_mangadao():
    print("[MANGADAO] Farming rewards from Mangadao pools... (Simulated)")